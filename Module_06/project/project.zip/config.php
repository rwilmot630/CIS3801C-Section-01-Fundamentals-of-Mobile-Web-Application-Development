<?php

$dbhost = 'localhost';
$dbuser = 'web';
$dbpass = 'cvgZeqGEmAhLdwCd';
$dbname = 'module3';

?>
